package TestLayerPackage;

import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayesPackage.baseclass;
import PageLayerPackage.Booking_ASC_DSC;

public class Booking_ASC_DSC_Test {
	public static Booking_ASC_DSC book;

	@Test(priority = 9)
	public void base() {
		baseclass.based();
		book = new Booking_ASC_DSC();
	}

	@Test(priority = 10)
	public void content_type_Test() {
		book.content_type();
	}
	@Test(priority = 11)
	public void createBody_and_heat_the_request_Test() {
		book.createBody_and_heat_the_request("2023-11-14", "ASC","N''");
	}
	@Test(priority = 12)
	public void hitthepost_Test() {
		book.hitthepost();
	}
	@Test(priority = 13)
	public void getbody_Test() {
		book.printbody();
//		book.validatebody();
		
	}
	@Test(priority = 14)
	public void verify_status_code_Test() {
		Assert.assertEquals(book.verify_status_code(), 200);
	}
	@Test(priority = 15)
	public void getStatusLine_Test() {
		Assert.assertEquals(book.verify_status_line(), "HTTP/1.1 200 OK");
	}
	@Test(priority = 16)
	public void verify_status_time_Test() {
		book.verify_status_time();
	}
}
