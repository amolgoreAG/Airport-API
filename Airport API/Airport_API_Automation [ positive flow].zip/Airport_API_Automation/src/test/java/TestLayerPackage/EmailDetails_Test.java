package TestLayerPackage;

import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayesPackage.baseclass;
import PageLayerPackage.EmailDetails;

public class EmailDetails_Test extends baseclass{


	public static EmailDetails email;

	@Test(priority = 49)
	public void base() {
		baseclass.based();
		email = new EmailDetails();
	}

	@Test(priority = 50)
	public void content_type_Test() {
		email.content_type();
	}
	@Test(priority = 51)
	public void createBody_and_heat_the_request_Test() {
		email.createBody_and_heat_the_request(28);
	}
	@Test(priority = 52)
	public void hitthepost_Test() {
		email.hitthepost();
	}
	@Test(priority = 53)
	public void getbody_Test() {
		email.printbody();
//		email.validatebody();
		
	}
	@Test(priority = 54)
	public void verify_status_code_Test() {
		Assert.assertEquals(email.verify_status_code(), 200);
	}
	@Test(priority = 55)
	public void getStatusLine_Test() {
		Assert.assertEquals(email.verify_status_line(), "HTTP/1.1 200 OK");
	}
	@Test(priority = 56)
	public void verify_status_time_Test() {
		email.verify_status_time();
	}
}
