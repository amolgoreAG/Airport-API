package TestLayerPackage;

import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayesPackage.baseclass;
import PageLayerPackage.GetTheDriverDutySheet;

public class GetTheDriverDutySheet_Test extends baseclass {

	public static GetTheDriverDutySheet driverDutySheet;

	@Test(priority = 41)
	public void base() {
		baseclass.based();
		driverDutySheet = new GetTheDriverDutySheet();
	}

	@Test(priority = 42)
	public void content_type_Test() {
		driverDutySheet.content_type();
	}
	@Test(priority = 43)
	public void createBody_and_heat_the_request_Test() {
		driverDutySheet.createBody_and_heat_the_request("2023/11/14");
	}
	@Test(priority = 44)
	public void hitthepost_Test() {
		driverDutySheet.hitthepost();
	}
	@Test(priority = 45)
	public void getbody_Test() {
		driverDutySheet.printbody();
//		driverDutySheet.validatebody();
		
	}
	@Test(priority = 46)
	public void verify_status_code_Test() {
		Assert.assertEquals(driverDutySheet.verify_status_code(), 200);
	}
	@Test(priority = 47)
	public void getStatusLine_Test() {
		Assert.assertEquals(driverDutySheet.verify_status_line(), "HTTP/1.1 200 OK");
	}
	@Test(priority = 48)
	public void verify_status_time_Test() {
		driverDutySheet.verify_status_time();
	}
}
