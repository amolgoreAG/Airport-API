package TestLayerPackage;

import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayesPackage.baseclass;
import PageLayerPackage.UpdateCostPrice;

public class UpdateCostPrice_Test extends baseclass {
	public static UpdateCostPrice updatecost;

	@Test(priority = 25)
	public void base() {
		baseclass.based();
		updatecost = new UpdateCostPrice();
	}

	@Test(priority = 26)
	public void content_type_Test() {
		updatecost.content_type();
	}
	@Test(priority = 27)
	public void createBody_and_heat_the_request_Test() {
		updatecost.createBody_and_heat_the_request("RP/000642");
	}
	@Test(priority = 28)
	public void hitthepost_Test() {
		updatecost.hitthepost();
	}
	@Test(priority = 29)
	public void getbody_Test() {
		updatecost.printbody();
//		updatecost.validatebody();
		
	}
	@Test(priority = 30)
	public void verify_status_code_Test() {
		Assert.assertEquals(updatecost.verify_status_code(), 200);
	}
	@Test(priority = 31)
	public void getStatusLine_Test() {
		Assert.assertEquals(updatecost.verify_status_line(), "HTTP/1.1 200 OK");
	}
	@Test(priority = 32)
	public void verify_status_time_Test() {
		updatecost.verify_status_time();
	}
}
