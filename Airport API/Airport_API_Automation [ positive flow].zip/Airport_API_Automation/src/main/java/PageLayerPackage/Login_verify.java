package PageLayerPackage;

import java.util.List;

import org.testng.Assert;

import com.google.gson.JsonObject;

import BaseLayesPackage.baseclass;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Login_verify extends baseclass {

	public static RequestSpecification httpRequest;
	public static Response response;
	public static Object token;

	public void content_type() {
		httpRequest = RestAssured.given();
		httpRequest.header("Content-Type", "application/json");
	}

	public void createBody_and_heat_the_request(String username, String password) {
		JsonObject loginCredentials = new JsonObject();
		loginCredentials.addProperty("username", username);
		loginCredentials.addProperty("password", password);
		httpRequest.body(loginCredentials.toString());
		System.out.println(loginCredentials.toString());

	}

	public void hitthepost() {
		response = httpRequest.post("/verify/");
	}

	public void printbody() {
		System.out.println(response.getBody().asPrettyString());
	}

	public void validatebody() {
		List<Object> list = response.jsonPath().getList("data.token");
		for (int i = 0; i < list.size(); i++) {
			System.out.println("Token : " + list.get(i));
			token = list.get(i);
		}
	}

	public int verify_status_code() {
		return response.getStatusCode();
	}

	public String verify_status_line() {
		return response.getStatusLine();
	}

	public int verify_status_time() {
		long time = response.time();
		int i = (int) time;
		Assert.assertTrue(i <= 200, "Response Time is more than 200 milliseconds: " + i);
		System.out.println("Perfect Response Time: " + i);
		return i;
	}
}
