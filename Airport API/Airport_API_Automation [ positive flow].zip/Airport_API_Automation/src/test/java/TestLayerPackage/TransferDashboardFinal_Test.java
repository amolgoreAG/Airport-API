package TestLayerPackage;

import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayesPackage.baseclass;
import PageLayerPackage.TransferDashboardFinal;

public class TransferDashboardFinal_Test extends baseclass {
	public static TransferDashboardFinal transferDashboardFinal;

	@Test(priority = 73)
	public void base() {
		baseclass.based();
		transferDashboardFinal = new TransferDashboardFinal();
	}

	@Test(priority = 74)
	public void content_type_Test() {
		transferDashboardFinal.content_type();
	}
	@Test(priority = 75)
	public void createBody_and_heat_the_request_Test() {
		transferDashboardFinal.createBody_and_heat_the_request("2023-07-14","2023-12-12");
	}
	@Test(priority = 76)
	public void hitthepost_Test() {
		transferDashboardFinal.hitthepost();
	}
	@Test(priority = 77)
	public void getbody_Test() {
		transferDashboardFinal.printbody();
//		transferDashboardFinal.validatebody();
		
	}
	@Test(priority = 78)
	public void verify_status_code_Test() {
		Assert.assertEquals(transferDashboardFinal.verify_status_code(), 200);
	}
	@Test(priority = 79)
	public void getStatusLine_Test() {
		Assert.assertEquals(transferDashboardFinal.verify_status_line(), "HTTP/1.1 200 OK");
	}
	@Test(priority = 80)
	public void verify_status_time_Test() {
		transferDashboardFinal.verify_status_time();
	}
}
