package TestLayerPackage;

import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayesPackage.baseclass;
import PageLayerPackage.priorTime;

public class priorTime_Test extends baseclass {

	public static priorTime prior;

	@Test(priority = 57)
	public void base() {
		baseclass.based();
		prior = new priorTime();
	}

	@Test(priority = 58)
	public void content_type_Test() {
		prior.content_type();
	}
	@Test(priority = 59)
	public void createBody_and_heat_the_request_Test() {
		prior.createBody_and_heat_the_request(5);
	}
	@Test(priority = 60)
	public void hitthepost_Test() {
		prior.hitthepost();
	}
	@Test(priority = 61)
	public void getbody_Test() {
		prior.printbody();
//		prior.validatebody();
		
	}
	@Test(priority = 62)
	public void verify_status_code_Test() {
		Assert.assertEquals(prior.verify_status_code(), 200);
	}
	@Test(priority = 63)
	public void getStatusLine_Test() {
		Assert.assertEquals(prior.verify_status_line(), "HTTP/1.1 200 OK");
	}
	@Test(priority = 64)
	public void verify_status_time_Test() {
		prior.verify_status_time();
	}
}
