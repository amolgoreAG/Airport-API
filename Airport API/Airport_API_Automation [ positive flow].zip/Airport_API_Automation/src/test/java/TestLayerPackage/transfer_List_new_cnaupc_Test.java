package TestLayerPackage;

import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayesPackage.baseclass;
import PageLayerPackage.transfer_List_new_cnaupc;

public class transfer_List_new_cnaupc_Test extends baseclass{
	public static transfer_List_new_cnaupc Transfer_List_new_cnaupc;

	@Test(priority = 81)
	public void base() {
		baseclass.based();
		Transfer_List_new_cnaupc = new transfer_List_new_cnaupc();
	}

	@Test(priority = 82)
	public void content_type_Test() {
		Transfer_List_new_cnaupc.content_type();
	}
	@Test(priority = 83)
	public void createBody_and_heat_the_request_Test() {
		Transfer_List_new_cnaupc.createBody_and_heat_the_request("2023-11-14","2023-11-14");
	}
	@Test(priority = 84)
	public void hitthepost_Test() {
		Transfer_List_new_cnaupc.hitthepost();
	}
	@Test(priority = 85)
	public void getbody_Test() {
		Transfer_List_new_cnaupc.printbody();
//		Transfer_List_new_cnaupc.validatebody();
		
	}
	@Test(priority = 86)
	public void verify_status_code_Test() {
		Assert.assertEquals(Transfer_List_new_cnaupc.verify_status_code(), 200);
	}
	@Test(priority = 87)
	public void getStatusLine_Test() {
		Assert.assertEquals(Transfer_List_new_cnaupc.verify_status_line(), "HTTP/1.1 200 OK");
	}
	@Test(priority = 88)
	public void verify_status_time_Test() {
		Transfer_List_new_cnaupc.verify_status_time();
	}
}
