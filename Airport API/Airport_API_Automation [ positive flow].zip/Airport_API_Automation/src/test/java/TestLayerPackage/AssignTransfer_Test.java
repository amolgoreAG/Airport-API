package TestLayerPackage;

import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayesPackage.baseclass;
import PageLayerPackage.AssignTransfer;

public class AssignTransfer_Test extends baseclass{
	public static AssignTransfer assignTransfer;

	@Test(priority = 65)
	public void base() {
		baseclass.based();
		assignTransfer = new AssignTransfer();
	}

	@Test(priority = 66)
	public void content_type_Test() {
		assignTransfer.content_type();
	}
	@Test(priority = 67)
	public void createBody_and_heat_the_request_Test() {
		assignTransfer.createBody_and_heat_the_request("2023/08/08","E/000012");
	}
	@Test(priority = 68)
	public void hitthepost_Test() {
		assignTransfer.hitthepost();
	}
	@Test(priority = 69)
	public void getbody_Test() {
		assignTransfer.printbody();
//		assignTransfer.validatebody();
		
	}
	@Test(priority = 70)
	public void verify_status_code_Test() {
		Assert.assertEquals(assignTransfer.verify_status_code(), 200);
	}
	@Test(priority = 71)
	public void getStatusLine_Test() {
		Assert.assertEquals(assignTransfer.verify_status_line(), "HTTP/1.1 200 OK");
	}
	@Test(priority = 72)
	public void verify_status_time_Test() {
		assignTransfer.verify_status_time();
	}
}
