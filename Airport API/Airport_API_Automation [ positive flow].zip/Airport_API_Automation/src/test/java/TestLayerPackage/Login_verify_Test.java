package TestLayerPackage;

import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayesPackage.baseclass;
import PageLayerPackage.Login_verify;

public class Login_verify_Test extends baseclass {

	public static Login_verify verify;

	@Test(priority = 1)
	public void base() throws InterruptedException {
		baseclass.based();
		verify = new Login_verify();
		Thread.sleep(5000);
	}

	@Test(priority = 2)
	public void content_type_Test() {
		verify.content_type();
	}
	@Test(priority = 3)
	public void createBody_and_heat_the_request_Test() {
		verify.createBody_and_heat_the_request("sam", "12345");
	}
	@Test(priority = 4)
	public void hitthepost_Test() {
		verify.hitthepost();
	}
	@Test(priority = 5)
	public void getbody_Test() {
		System.out.println();
		System.err.println("Scenario : Username and Passsword both are Correct : ");
		System.out.println();
		verify.printbody();
		verify.validatebody();
		
	}
	@Test(priority = 6)
	public void verify_status_code_Test() {
		Assert.assertEquals(verify.verify_status_code(), 200);
	}
	@Test(priority = 7)
	public void getStatusLine_Test() {
		Assert.assertEquals(verify.verify_status_line(), "HTTP/1.1 200 OK");
	}
	@Test(priority = 8)
	public void verify_status_time_Test() {
		verify.verify_status_time();
	}
}
