package TestLayerPackage;

import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayesPackage.baseclass;
import PageLayerPackage.assign_driver_or_supplier;

public class assign_driver_or_supplier_Test extends baseclass {

	public static assign_driver_or_supplier assigndriver;

	@Test(priority = 33)
	public void base() {
		baseclass.based();
		assigndriver = new assign_driver_or_supplier();
	}

	@Test(priority = 34)
	public void content_type_Test() {
		assigndriver.content_type();
	}
	@Test(priority = 35)
	public void createBody_and_heat_the_request_Test() {
		assigndriver.createBody_and_heat_the_request(1041,"");
	}
	@Test(priority = 36)
	public void hitthepost_Test() {
		assigndriver.hitthepost();
	}
	@Test(priority = 37)
	public void getbody_Test() {
		assigndriver.printbody();
//		assigndriver.validatebody();
		
	}
	@Test(priority = 38)
	public void verify_status_code_Test() {
		Assert.assertEquals(assigndriver.verify_status_code(), 200);
	}
	@Test(priority = 39)
	public void getStatusLine_Test() {
		Assert.assertEquals(assigndriver.verify_status_line(), "HTTP/1.1 200 OK");
	}
	@Test(priority = 40)
	public void verify_status_time_Test() {
		assigndriver.verify_status_time();
	}
}
