package BaseLayesPackage;

import io.restassured.RestAssured;

public class baseclass {

	public int timeoutInMilliseconds=10000;
	
	public static void based() {
		RestAssured.baseURI="http://150.242.13.125:9092";	
		}


}

